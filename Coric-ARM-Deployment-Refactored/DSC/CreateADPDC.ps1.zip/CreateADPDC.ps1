﻿configuration CreateADPDC 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, PSDesiredStateConfiguration
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    $DomainDN = "DC=$($DomainName.Split(".")[0]),DC=$($DomainName.Split(".")[1])"
    $ServerRolesOU = "Coric Server Roles"
    $AccountsOU = "Coric Accounts"

    Node localhost
    {
        Script AddADDSFeature {
            SetScript = {
                Install-WindowsFeature "AD-Domain-Services" -IncludeManagementTools -ErrorAction SilentlyContinue   
            }
            GetScript =  { @{} }
            TestScript = { $false }
        }

        WindowsFeature File-Services
        {
            Ensure = "Present"
            Name = "File-Services"
        }

        WindowsFeature FS-Resource-Manager
        {
            Ensure = "Present"
            Name = "FS-Resource-Manager"
        }
	
	    WindowsFeature DNS 
        { 
            Ensure = "Present"
            Name = "DNS"
        }

        Script script1
	    {
      	    SetScript =  { 
		        Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            GetScript =  { @{} }
            TestScript = { $false }
	        DependsOn = "[WindowsFeature]DNS"
        }

	    WindowsFeature DnsTools
	    {
	        Ensure = "Present"
            Name = "RSAT-DNS-Server"
	    }

        xDnsServerAddress DnsServerAddress 
        { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
	        DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
	        DependsOn="[WindowsFeature]File-Services", "[WindowsFeature]FS-Resource-Manager", "[Script]AddADDSFeature"
        }

        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "C:\Windows\NTDS"
            LogPath = "C:\Windows\NTDS"
            SysvolPath = "C:\Windows\SYSVOL"
	        DependsOn = "[WindowsFeature]ADDSInstall"
        } 

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        xADOrganizationalUnit ServerRoles
        {
            Name = $ServerRolesOU
            Path = $DomainDN
            Ensure = "Present"
            DependsOn = "[xADDomain]FirstDS"
        }

        xADOrganizationalUnit SQL
        {
            Name = "SQL"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit Drone
        {
            Name = "Drone"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit Desktop
        {
            Name = "Desktop"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit IIS
        {
            Name = "IIS"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit RDG
        {
            Name = "RDG"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit FTP
        {
            Name = "FTP"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit PushPull
        {
            Name = "PushPull"
            Path = "OU=$ServerRolesOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]ServerRoles"
        }

        xADOrganizationalUnit Accounts
        {
            Name = $AccountsOU
            Path = $DomainDN
            Ensure = "Present"
            DependsOn = "[xADDomain]FirstDS"
        }

        xADOrganizationalUnit ClientUser
        {
            Name = "Client User"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }

        xADOrganizationalUnit DocumentWarehouse
        {
            Name = "Document Warehouse"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }

        xADOrganizationalUnit DocumentWarehouseAccess
        {
            Name = "Document Warehouse Access"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }

        xADOrganizationalUnit Groups
        {
            Name = "Groups"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }

        xADOrganizationalUnit ServiceAccounts
        {
            Name = "Service Accounts"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }

        xADOrganizationalUnit Support
        {
            Name = "Support"
            Path = "OU=$AccountsOU,$DomainDN"
            Ensure = "Present"
            DependsOn = "[xADOrganizationalUnit]Accounts"
        }
   }
} 