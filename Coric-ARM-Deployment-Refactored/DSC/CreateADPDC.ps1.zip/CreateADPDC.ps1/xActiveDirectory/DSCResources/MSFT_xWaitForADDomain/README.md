# Description

The xWaitForADDomain resource is used to wait for Active Directory to become available.

## Requirements

* Target machine must be running Windows Server 2008 R2 or later.
