﻿if ($ENV:COMPUTERNAME.Substring(8, 2).ToLower() -ne 'dc')
{
    Write-Warning 'This is a domain controller script but the server does not appear to be a domain controller. Aborting...'
    exit
}

$scriptDirPath = 'C:\ScriptLibrary\CreateADPDC.ps1'

if (-not (Test-Path -Path ($scriptDirPath + '\CreateADPDC.ps1') -PathType Leaf))
{
    Write-Warning "The CreateADPDC.ps1 file must exist in the folder '$scriptDirPath'. Aborting..."
    exit
}

$domain = ($ENV:COMPUTERNAME -split '-')[0] + '.Hosted'

$dscConfigPath = 'C:\ScriptLibrary\CreateADPDC.ps1'
Push-Location $dscConfigPath

# The "CreateADPDC.ps1" script must exist in the current working directory.
$configName = 'CreateADPDC'

Import-Module PSDesiredStateConfiguration
Import-Module ".\xNetworking"
Import-Module ".\xActiveDirectory"
Import-Module ".\xPendingReboot"
Import-Module (".\{0}.ps1" -f $configName)

if (-not $cred) { $cred = Get-Credential -Message 'Enter Domain Admin credential and password' }

# Compiles DSC configuration into a .mof file in a newly created directory with the same name as the DSC config
CreateADPDC -DomainName $domain -AdminCreds $cred -ConfigurationData $configData -WarningAction Ignore

Start-DscConfiguration -Path $configName -Wait -Force -Verbose

Pop-Location
