﻿$domain = Get-ADDomain | Select -Expand DNSRoot
if (-not $cred) { $cred = Get-Credential -Message 'Enter Domain Admin credential and password' }
$path = "CreateADPDC"

CreateADPDC -DomainName $domain -AdminCreds $cred -ConfigurationData $configData

Start-DscConfiguration -Path $path -Wait -Force -Verbose
